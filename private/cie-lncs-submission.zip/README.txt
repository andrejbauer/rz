To generate the PDF file for LNCS proceedings, run the following
commands:

pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex

If you have any questions or problems, please contact me at
Andrej.Bauer@andrej.com.
